/*
 * Copyright (C), 2016-2017, 众安信息科技
 * FileName: HelloService.java
 * Author:   za-lucunyu
 * Date:     2016年12月23日 下午3:10:08
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package cc.kevinlu.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 功能   
 *
 * @author za-lucunyu
 *
 */
@FeignClient("hello")
public interface HelloService {
	

	@RequestMapping(value = "/say/{name}", method = RequestMethod.GET)
	String sayHello(@PathVariable("name") String name);

}
